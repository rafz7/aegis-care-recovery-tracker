// AegisCare — Mock discharge dataset
// This represents the structured output of parsing a raw discharge summary
// ("resume medis pulang") into the shape the dashboard consumes.

export type MedicationBlock = "Pagi" | "Malam" | "PRN";

export interface Medication {
  id: string;
  name: string;
  dose: string;
  block: MedicationBlock;
  windowLabel: string; // e.g. "07.00 – 08.00"
  purpose: string; // layman explanation of what it does
  caution?: string; // special instruction, e.g. "take with food"
  warning?: string; // hard safety warning, shown as a badge (PRN meds)
  maxPerDay?: number;
}

export interface DoseLog {
  medicationId: string;
  takenAt: string; // ISO timestamp
}

export interface ChecklistItem {
  id: string;
  label: string;
}

export interface PatientRecord {
  name: string;
  age: number;
  mrn: string;
  dpjp: string; // attending cardiologist
  diagnosisClinical: string;
  diagnosisLayman: string;
  procedure: string;
  allergy: string;
  punctureSite: string;
  followUp: {
    dateISO: string; // appointment datetime
    location: string;
    doctor: string;
  };
  woundCare: {
    dryDays: number;
    instructions: string[];
    donts: string[];
  };
  mobility: {
    weightLimitKg: number;
    allowed: string;
    restricted: string;
  };
  bowel: string;
  fluid: {
    maxMl: number;
    warningThresholdMl: number;
  };
  diet: {
    label: string;
    kcal: number;
    rules: string[];
  };
  medications: Medication[];
  checklist: ChecklistItem[];
  redFlags: string[];
}

export const mockPatient: PatientRecord = {
  name: "Tn. Bambang Hermanto",
  age: 58,
  mrn: "00-48-29-11",
  dpjp: "dr. Sutrisno, Sp.JP",
  diagnosisClinical: "Post-STEMI Anterior Ekstensif",
  diagnosisLayman: "Serangan Jantung Akut",
  procedure: "Pasang 1 Ring Jantung (DES) di Arteri LAD",
  allergy: "Golongan Penisilin (Amoxicillin)",
  punctureSite: "Pergelangan tangan kanan (akses radial)",
  followUp: {
    dateISO: "2026-09-18T09:00:00+07:00",
    location: "Poliklinik Jantung",
    doctor: "dr. Sutrisno, Sp.JP",
  },
  woundCare: {
    dryDays: 3,
    instructions: [
      "Jaga balutan tetap kering dan bersih selama 3 hari",
      "Boleh mandi dengan menutup area luka memakai plastik/penutup kedap air",
      "Ganti balutan sesuai jadwal dari perawat bila basah atau kotor",
    ],
    donts: [
      "Jangan membasahi balutan luka secara langsung",
      "Jangan menggaruk atau menekan area bekas suntik",
      "Jangan melepas balutan sendiri sebelum jadwal kontrol",
    ],
  },
  mobility: {
    weightLimitKg: 3,
    allowed: "Jalan kaki ringan 10–15 menit di dalam rumah, boleh dilakukan bertahap",
    restricted: "Angkat beban lebih dari 3 kg dengan tangan kanan (setara 1 galon air penuh)",
  },
  bowel: "Dilarang mengejan keras saat buang air besar — minum air cukup dan konsumsi serat agar BAB lancar",
  fluid: {
    maxMl: 1500,
    warningThresholdMl: 1400,
  },
  diet: {
    label: "Diet Jantung Rendah Garam & Rendah Kolesterol",
    kcal: 1700,
    rules: [
      "Rendah garam — hindari makanan asin, olahan, dan penyedap berlebih",
      "Rendah kolesterol — hindari gorengan, jeroan, dan santan kental",
      "Hindari gula murni — gunakan pemanis pengganti bila perlu (pasien diabetes)",
      "Porsi kecil tapi sering, 5–6 kali makan per hari",
    ],
  },
  medications: [
    {
      id: "aspilet",
      name: "Aspilet",
      dose: "80mg",
      block: "Pagi",
      windowLabel: "07.00 – 08.00",
      purpose: "Mencegah penggumpalan darah agar ring jantung tidak tersumbat",
      caution: "Minum setelah makan untuk menghindari perih lambung",
    },
    {
      id: "clopidogrel",
      name: "Clopidogrel",
      dose: "75mg",
      block: "Pagi",
      windowLabel: "07.00 – 08.00",
      purpose: "Mengencerkan darah bersama Aspilet, mencegah sumbatan pada ring jantung",
      caution: "Jangan dihentikan sendiri tanpa instruksi dokter, meski terasa sudah sehat",
    },
    {
      id: "bisoprolol",
      name: "Bisoprolol",
      dose: "2.5mg",
      block: "Pagi",
      windowLabel: "07.00 – 08.00",
      purpose: "Meringankan kerja jantung dan menjaga irama tetap stabil",
      caution: "Jangan dihentikan mendadak — dapat memicu denyut jantung tidak beraturan",
    },
    {
      id: "metformin-pagi",
      name: "Metformin",
      dose: "500mg",
      block: "Pagi",
      windowLabel: "07.00 – 08.00",
      purpose: "Mengontrol kadar gula darah",
      caution: "Wajib diminum bersama suapan makan pertama untuk menghindari mual",
    },
    {
      id: "atorvastatin",
      name: "Atorvastatin",
      dose: "40mg",
      block: "Malam",
      windowLabel: "20.00 – 21.00",
      purpose: "Menurunkan kolesterol jahat penyebab penyumbatan pembuluh darah",
      caution: "Lebih efektif diminum malam hari",
    },
    {
      id: "metformin-malam",
      name: "Metformin",
      dose: "500mg",
      block: "Malam",
      windowLabel: "20.00 – 21.00",
      purpose: "Mengontrol kadar gula darah di malam hari",
      caution: "Wajib bersama suapan makan malam",
    },
    {
      id: "isdn",
      name: "ISDN",
      dose: "5mg Sublingual",
      block: "PRN",
      windowLabel: "Bila Nyeri Dada",
      purpose: "Meredakan nyeri dada dengan melebarkan pembuluh darah jantung",
      warning: "Maksimal 3 kali dengan jeda 5 menit. Taruh di bawah lidah, jangan ditelan.",
      maxPerDay: 3,
    },
  ],
  checklist: [
    { id: "resume", label: "Lembar Resume Medis Asli" },
    { id: "ekg", label: "Rekaman EKG Pulang" },
    { id: "bpjs", label: "Kartu BPJS Kesehatan Aktif" },
    { id: "obat", label: "Sisa Obat-obatan yang Belum Habis" },
  ],
  redFlags: [
    "Nyeri dada lebih dari 15 menit yang tidak membaik setelah minum ISDN",
    "Saturasi oksigen (SpO2) turun di bawah normal / sesak napas berat",
    "Perdarahan hebat di area bekas suntik kateter (pergelangan tangan)",
    "Keringat dingin disertai lemas atau pusing berat",
  ],
};
