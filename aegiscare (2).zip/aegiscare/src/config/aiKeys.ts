// AegisCare — Aegis Partner runtime configuration
// ─────────────────────────────────────────────────────────────────────────
// The actual values are set by the site owner directly in index.html
// (see the "PENGATURAN AEGIS PARTNER" block near the top of that file),
// not here. That keeps configuration editable after the app is built —
// no rebuild needed to change keys, just edit and re-upload index.html.
//
// This file only reads whatever was placed on `window` and exposes it
// under stable internal names for the rest of the app to use.

declare global {
  interface Window {
    __AEGIS_PARTNER_CONFIG__?: {
      kunciUtama?: string;
      kunciCadangan?: string;
    };
  }
}

const runtimeConfig = typeof window !== "undefined" ? window.__AEGIS_PARTNER_CONFIG__ : undefined;

export const AI_KEYS = {
  geminiApiKey: runtimeConfig?.kunciUtama?.trim() || "",
  groqApiKey: runtimeConfig?.kunciCadangan?.trim() || "",
};
