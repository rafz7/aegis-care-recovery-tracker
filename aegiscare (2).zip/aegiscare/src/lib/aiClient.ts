import { AI_KEYS } from "../config/aiKeys";

export interface AIResult {
  text: string;
}

export interface AIFilePart {
  mimeType: string;
  base64Data: string; // without the "data:...;base64," prefix
}

class AIProviderError extends Error {}

// Five-tier fallback chain. Each tier is tried in order; on any failure
// (missing key, rate limit, timeout, network error, bad response) the next
// tier runs automatically. Tiers 1–3 use the primary service key and can see
// attached files (images/PDFs). Tiers 4–5 use the backup service key and are
// text-only, so they're skipped automatically when a file is attached.
type Tier = () => Promise<AIResult>;

const TIMEOUT_MS = 20_000;

async function withTimeout<T>(promise: Promise<T>, ms: number): Promise<T> {
  return Promise.race([
    promise,
    new Promise<T>((_, reject) => setTimeout(() => reject(new AIProviderError("timeout")), ms)),
  ]);
}

async function callGemini(
  model: string,
  systemPrompt: string,
  userPrompt: string,
  file?: AIFilePart
): Promise<AIResult> {
  if (!AI_KEYS.geminiApiKey) throw new AIProviderError("kunci utama belum diisi");

  const parts: Record<string, unknown>[] = [{ text: userPrompt }];
  if (file) {
    parts.unshift({ inlineData: { mimeType: file.mimeType, data: file.base64Data } });
  }

  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${AI_KEYS.geminiApiKey}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: systemPrompt }] },
        contents: [{ role: "user", parts }],
        generationConfig: { temperature: 0.4, maxOutputTokens: 700 },
      }),
    }
  );

  if (!res.ok) throw new AIProviderError(`${model} HTTP ${res.status}`);
  const data = await res.json();
  const text = data?.candidates?.[0]?.content?.parts?.map((p: { text?: string }) => p.text ?? "").join("");
  if (!text) throw new AIProviderError(`${model} respons kosong`);
  return { text };
}

async function callGroq(model: string, systemPrompt: string, userPrompt: string): Promise<AIResult> {
  if (!AI_KEYS.groqApiKey) throw new AIProviderError("kunci cadangan belum diisi");

  const res = await fetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${AI_KEYS.groqApiKey}`,
    },
    body: JSON.stringify({
      model,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
      temperature: 0.4,
      max_tokens: 700,
    }),
  });

  if (!res.ok) throw new AIProviderError(`${model} HTTP ${res.status}`);
  const data = await res.json();
  const text = data?.choices?.[0]?.message?.content;
  if (!text) throw new AIProviderError(`${model} respons kosong`);
  return { text };
}

/**
 * Runs each tier in order, falling through to the next on any failure.
 * When a file is attached, only the vision-capable tiers (1–3) are used,
 * since the backup text-only service cannot see images/PDFs.
 * Throws only if every eligible tier fails.
 */
export async function askAIPartner(
  systemPrompt: string,
  userPrompt: string,
  file?: AIFilePart
): Promise<AIResult> {
  const visionTiers: Tier[] = [
    () => withTimeout(callGemini("gemini-2.5-flash", systemPrompt, userPrompt, file), TIMEOUT_MS),
    () => withTimeout(callGemini("gemini-2.5-flash-lite", systemPrompt, userPrompt, file), TIMEOUT_MS),
    () => withTimeout(callGemini("gemini-3.5-flash", systemPrompt, userPrompt, file), TIMEOUT_MS),
  ];
  const textOnlyTiers: Tier[] = [
    () => withTimeout(callGroq("openai/gpt-oss-120b", systemPrompt, userPrompt), TIMEOUT_MS),
    () => withTimeout(callGroq("openai/gpt-oss-20b", systemPrompt, userPrompt), TIMEOUT_MS),
  ];

  const tiers = file ? visionTiers : [...visionTiers, ...textOnlyTiers];

  const errors: string[] = [];
  for (const tier of tiers) {
    try {
      return await tier();
    } catch (err) {
      errors.push(err instanceof Error ? err.message : String(err));
    }
  }

  throw new Error(
    file
      ? `Analisis file gagal di semua model pendukung (${errors.join(" · ")}).`
      : `Semua layanan gagal merespons (${errors.join(" · ")}). Pastikan konfigurasi sudah diisi di index.html.`
  );
}
