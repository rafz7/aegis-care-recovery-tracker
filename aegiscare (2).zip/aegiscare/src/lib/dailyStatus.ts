import { mockPatient } from "../data/mockPatient";

function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function readJSON<T>(key: string, fallback: T): T {
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export interface DailyStatus {
  medsTaken: number;
  medsTotal: number;
  medsRemaining: string[]; // names of scheduled meds not yet taken today
  prnTakenToday: number;
  prnMax: number;
  fluidMl: number;
  fluidMaxMl: number;
  checklistDone: number;
  checklistTotal: number;
  daysToFollowUp: number;
}

export function getDailyStatus(): DailyStatus {
  const key = todayKey();

  const doseLog = readJSON<{ medicationId: string; dateKey: string; timestamps: string[] }[]>(
    "aegiscare.doseLog",
    []
  );
  const entriesToday = doseLog.filter((e) => e.dateKey === key);

  const scheduledMeds = mockPatient.medications.filter((m) => m.block !== "PRN");
  const prnMed = mockPatient.medications.find((m) => m.block === "PRN");

  const takenIds = new Set(entriesToday.map((e) => e.medicationId));
  const medsTaken = scheduledMeds.filter((m) => takenIds.has(m.id)).length;
  const medsRemaining = scheduledMeds.filter((m) => !takenIds.has(m.id)).map((m) => `${m.name} ${m.dose}`);

  const prnEntry = prnMed ? entriesToday.find((e) => e.medicationId === prnMed.id) : undefined;
  const prnTakenToday = prnEntry?.timestamps.length ?? 0;

  const fluid = readJSON<{ dateKey: string; ml: number }>("aegiscare.fluid", { dateKey: key, ml: 0 });
  const fluidMl = fluid.dateKey === key ? fluid.ml : 0;

  const checklist = readJSON<Record<string, boolean>>("aegiscare.checklist", {});
  const checklistDone = mockPatient.checklist.filter((c) => checklist[c.id]).length;

  const daysToFollowUp = Math.max(
    0,
    Math.ceil((new Date(mockPatient.followUp.dateISO).getTime() - Date.now()) / (1000 * 60 * 60 * 24))
  );

  return {
    medsTaken,
    medsTotal: scheduledMeds.length,
    medsRemaining,
    prnTakenToday,
    prnMax: prnMed?.maxPerDay ?? 3,
    fluidMl,
    fluidMaxMl: mockPatient.fluid.maxMl,
    checklistDone,
    checklistTotal: mockPatient.checklist.length,
    daysToFollowUp,
  };
}
