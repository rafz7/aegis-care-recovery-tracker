import { useMemo } from "react";
import { GlassWater, AlertTriangle, Salad, RotateCcw } from "lucide-react";
import { mockPatient } from "../data/mockPatient";
import { useLocalStorage } from "../lib/useLocalStorage";
import { cn } from "../lib/utils";

function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

export function HydrationDietTracker() {
  const key = todayKey();
  const [fluid, setFluid] = useLocalStorage<{ dateKey: string; ml: number }>("aegiscare.fluid", {
    dateKey: key,
    ml: 0,
  });

  const ml = fluid.dateKey === key ? fluid.ml : 0;
  const { maxMl, warningThresholdMl } = mockPatient.fluid;
  const pct = Math.min(100, (ml / maxMl) * 100);
  const isWarning = ml >= warningThresholdMl && ml < maxMl;
  const isOver = ml >= maxMl;

  const barColor = useMemo(() => (isOver ? "bg-danger-500" : isWarning ? "bg-warn-500" : "bg-clinical-600"), [
    isOver,
    isWarning,
  ]);

  function addMl(amount: number) {
    setFluid({ dateKey: key, ml: Math.max(0, ml + amount) });
  }

  function reset() {
    setFluid({ dateKey: key, ml: 0 });
  }

  return (
    <section className="rounded-2xl border border-line bg-surface p-5 shadow-card sm:p-6" aria-label="Asupan cairan dan diet">
      <div className="flex items-center justify-between">
        <h2 className="font-display text-lg font-semibold text-ink">Asupan Cairan Harian</h2>
        <button
          onClick={reset}
          className="flex items-center gap-1 rounded-lg px-2 py-1 text-xs text-ink-faint transition hover:bg-canvas hover:text-ink"
        >
          <RotateCcw className="h-3.5 w-3.5" /> Ulangi
        </button>
      </div>

      <div className="mt-3 flex items-baseline gap-1.5">
        <span className="font-display text-3xl font-semibold text-ink">{ml.toLocaleString("id-ID")}</span>
        <span className="text-sm text-ink-soft">ml / maks {maxMl.toLocaleString("id-ID")} ml</span>
      </div>

      <div className="mt-2 h-3 w-full overflow-hidden rounded-full bg-canvas">
        <div className={cn("h-full rounded-full transition-all duration-500", barColor)} style={{ width: `${pct}%` }} />
      </div>

      {isOver ? (
        <p className="mt-2 flex items-center gap-1.5 text-sm font-medium text-danger-600">
          <AlertTriangle className="h-4 w-4" /> Batas cairan harian sudah tercapai. Hindari minum berlebih.
        </p>
      ) : isWarning ? (
        <p className="mt-2 flex items-center gap-1.5 text-sm font-medium text-warn-600">
          <AlertTriangle className="h-4 w-4" /> Mendekati batas harian — perhatikan sisa asupan.
        </p>
      ) : null}

      <div className="mt-4 flex gap-2">
        <button
          onClick={() => addMl(200)}
          className="flex min-h-[44px] flex-1 items-center justify-center gap-1.5 rounded-xl bg-clinical-50 text-sm font-semibold text-clinical-700 transition duration-150 hover:bg-clinical-100 active:scale-95"
        >
          <GlassWater className="h-4 w-4" /> +200 ml
        </button>
        <button
          onClick={() => addMl(250)}
          className="flex min-h-[44px] flex-1 items-center justify-center gap-1.5 rounded-xl bg-clinical-50 text-sm font-semibold text-clinical-700 transition duration-150 hover:bg-clinical-100 active:scale-95"
        >
          <GlassWater className="h-4 w-4" /> +250 ml
        </button>
      </div>

      <div className="mt-5 rounded-xl bg-canvas p-4">
        <p className="mb-2 flex items-center gap-2 text-sm font-semibold text-ink">
          <Salad className="h-4 w-4 text-safe-600" aria-hidden="true" />
          {mockPatient.diet.label} · {mockPatient.diet.kcal} kkal
        </p>
        <ul className="space-y-1.5">
          {mockPatient.diet.rules.map((rule, i) => (
            <li key={i} className="text-sm text-ink-soft">
              {rule}
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
