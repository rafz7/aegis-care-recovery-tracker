import { useState } from "react";
import { AlertTriangle, Phone, X, Siren } from "lucide-react";
import { mockPatient } from "../data/mockPatient";
import { Modal } from "./Modal";

export function EmergencyBanner() {
  const [open, setOpen] = useState(false);

  return (
    <>
      <div className="sticky top-0 z-40 bg-danger-500 text-white">
        <div className="mx-auto flex max-w-3xl items-center gap-3 px-4 py-2.5 sm:px-6">
          <span className="relative flex h-5 w-5 shrink-0 items-center justify-center" aria-hidden="true">
            <span className="absolute inline-flex h-full w-full animate-pulseRing rounded-full" />
            <Siren className="relative h-5 w-5" />
          </span>
          <p className="flex-1 text-sm font-medium leading-snug sm:text-base">
            Kenali tanda bahaya sebelum terlambat.
          </p>
          <button
            onClick={() => setOpen(true)}
            className="min-h-[44px] shrink-0 rounded-lg bg-white/15 px-3 py-2 text-sm font-semibold ring-1 ring-inset ring-white/40 transition duration-150 hover:bg-white/25 active:scale-95"
          >
            Darurat Medis (IGD)
          </button>
        </div>
      </div>

      <Modal open={open} onClose={() => setOpen(false)} labelledBy="triage-title">
        <div className="max-h-[90vh] overflow-y-auto">
          <div className="flex items-start justify-between border-b border-line px-5 py-4">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-danger-500" aria-hidden="true" />
              <h2 id="triage-title" className="font-display text-lg font-semibold text-ink">
                Segera ke IGD bila mengalami:
              </h2>
            </div>
            <button
              onClick={() => setOpen(false)}
              aria-label="Tutup"
              className="rounded-full p-2 text-ink-faint transition hover:bg-canvas hover:text-ink active:scale-90"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          <ul className="space-y-3 px-5 py-4">
            {mockPatient.redFlags.map((flag, i) => (
              <li key={i} className="flex gap-3 rounded-xl bg-danger-50 p-3 text-sm text-ink">
                <span className="mt-0.5 h-2 w-2 shrink-0 rounded-full bg-danger-500" aria-hidden="true" />
                <span>{flag}</span>
              </li>
            ))}
          </ul>

          <div className="space-y-2 border-t border-line px-5 py-4">
            <a
              href="tel:119"
              className="flex min-h-[52px] w-full items-center justify-center gap-2 rounded-xl bg-danger-500 text-base font-semibold text-white transition duration-150 hover:bg-danger-600 active:scale-[0.98]"
            >
              <Phone className="h-5 w-5" />
              Hubungi IGD / 119 Sekarang
            </a>
            <p className="text-center text-xs text-ink-faint">
              Bila memungkinkan, segera menuju IGD rumah sakit terdekat sambil menunggu bantuan.
            </p>
          </div>
        </div>
      </Modal>
    </>
  );
}
