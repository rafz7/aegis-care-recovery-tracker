import { useState } from "react";
import { FileText, Sparkles, Upload, X } from "lucide-react";
import { Modal } from "./Modal";

interface DischargeImporterProps {
  onLoadDemo: () => void;
}

export function DischargeImporter({ onLoadDemo }: DischargeImporterProps) {
  const [open, setOpen] = useState(false);
  const [raw, setRaw] = useState("");
  const [status, setStatus] = useState<null | "parsing" | "unsupported">(null);

  function handleParse() {
    if (!raw.trim()) return;
    // This demo build recognizes the seeded case only; a production version
    // would send `raw` to a clinical-NLP parsing service.
    setStatus("parsing");
    setTimeout(() => {
      setStatus("unsupported");
    }, 700);
  }

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="flex min-h-[44px] items-center gap-2 rounded-xl border border-line bg-surface px-4 py-2 text-sm font-medium text-ink-soft shadow-card transition duration-150 hover:border-clinical-400 hover:text-clinical-700 active:scale-95"
      >
        <FileText className="h-4 w-4" />
        Muat Resume Medis Lain
      </button>

      <Modal open={open} onClose={() => setOpen(false)} labelledBy="importer-title" widthClass="max-w-lg">
        <div className="max-h-[90vh] overflow-y-auto p-5">
          <div className="flex items-start justify-between">
            <h2 id="importer-title" className="font-display text-lg font-semibold text-ink">
              Muat Resume Medis
            </h2>
            <button
              onClick={() => setOpen(false)}
              aria-label="Tutup"
              className="rounded-full p-1.5 text-ink-faint hover:bg-canvas hover:text-ink active:scale-90"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
          <p className="mt-1 text-sm text-ink-soft">
            Tempel teks resume medis pulang untuk mengisi dasbor secara otomatis, atau gunakan data contoh.
          </p>

          <textarea
            value={raw}
            onChange={(e) => setRaw(e.target.value)}
            placeholder="Tempel teks resume medis di sini…"
            rows={6}
            className="mt-4 w-full rounded-xl border border-line bg-canvas p-3 text-sm text-ink outline-none transition focus:border-clinical-400"
          />

          {status === "unsupported" && (
            <p className="mt-2 rounded-lg bg-warn-50 p-3 text-sm text-warn-600">
              Mode demo ini hanya dapat memproses kasus contoh Tn. Bambang. Gunakan tombol "Muat Data Demo" di bawah.
            </p>
          )}

          <div className="mt-4 flex flex-col gap-2 sm:flex-row">
            <button
              onClick={handleParse}
              disabled={status === "parsing"}
              className="flex min-h-[44px] flex-1 items-center justify-center gap-2 rounded-xl bg-clinical-600 text-sm font-semibold text-white transition duration-150 hover:bg-clinical-700 active:scale-[0.98] disabled:opacity-60"
            >
              <Upload className="h-4 w-4" />
              {status === "parsing" ? "Memproses…" : "Proses Teks Ini"}
            </button>
            <button
              onClick={() => {
                onLoadDemo();
                setOpen(false);
                setStatus(null);
                setRaw("");
              }}
              className="flex min-h-[44px] flex-1 items-center justify-center gap-2 rounded-xl bg-safe-500 text-sm font-semibold text-white transition duration-150 hover:bg-safe-600 active:scale-[0.98]"
            >
              <Sparkles className="h-4 w-4" />
              Muat Data Demo
            </button>
          </div>
        </div>
      </Modal>
    </>
  );
}
