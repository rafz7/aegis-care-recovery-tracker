import { Droplets, Weight, Footprints, Check, X } from "lucide-react";
import { mockPatient } from "../data/mockPatient";

export function CareProtocol() {
  const { woundCare, mobility, bowel, punctureSite } = mockPatient;

  return (
    <section className="rounded-2xl border border-line bg-surface p-5 shadow-card sm:p-6" aria-label="Protokol perawatan luka dan mobilisasi">
      <h2 className="font-display text-lg font-semibold text-ink">Perawatan Luka & Aktivitas Harian</h2>

      <div className="mt-4 flex items-center gap-2 rounded-xl bg-clinical-50 p-3">
        <Droplets className="h-5 w-5 shrink-0 text-clinical-600" aria-hidden="true" />
        <p className="text-sm text-ink">
          Area akses tindakan: <span className="font-medium">{punctureSite}</span> — jaga tetap kering selama{" "}
          <span className="font-medium">{woundCare.dryDays} hari</span>.
        </p>
      </div>

      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        <div className="rounded-xl border border-safe-100 bg-safe-50 p-4">
          <p className="mb-2 flex items-center gap-2 text-sm font-semibold text-safe-600">
            <Check className="h-4 w-4" /> Boleh Dilakukan
          </p>
          <ul className="space-y-2">
            {woundCare.instructions.map((item, i) => (
              <li key={i} className="text-sm text-ink-soft">
                {item}
              </li>
            ))}
            <li className="text-sm text-ink-soft">{mobility.allowed}</li>
          </ul>
        </div>

        <div className="rounded-xl border border-danger-100 bg-danger-50 p-4">
          <p className="mb-2 flex items-center gap-2 text-sm font-semibold text-danger-600">
            <X className="h-4 w-4" /> Tidak Boleh Dilakukan
          </p>
          <ul className="space-y-2">
            {woundCare.donts.map((item, i) => (
              <li key={i} className="text-sm text-ink-soft">
                {item}
              </li>
            ))}
            <li className="text-sm text-ink-soft">{bowel}</li>
          </ul>
        </div>
      </div>

      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        <div className="rounded-xl bg-canvas p-4">
          <p className="mb-2 flex items-center gap-2 text-sm font-semibold text-ink">
            <Weight className="h-4 w-4 text-warn-500" aria-hidden="true" />
            Batas Angkat Beban
          </p>
          <div className="flex items-center gap-3">
            <div className="relative h-3 flex-1 overflow-hidden rounded-full bg-line">
              <div className="h-full w-full bg-gradient-to-r from-safe-500 via-warn-500 to-danger-500" />
              <div
                className="absolute top-1/2 h-5 w-1.5 -translate-y-1/2 rounded-full bg-ink"
                style={{ left: "35%" }}
                aria-hidden="true"
              />
            </div>
            <span className="shrink-0 text-sm font-semibold text-warn-600">Maks. {mobility.weightLimitKg} kg</span>
          </div>
          <p className="mt-2 text-xs text-ink-faint">{mobility.restricted}</p>
        </div>

        <div className="rounded-xl bg-canvas p-4">
          <p className="mb-2 flex items-center gap-2 text-sm font-semibold text-ink">
            <Footprints className="h-4 w-4 text-clinical-600" aria-hidden="true" />
            Mobilisasi Hari Ini
          </p>
          <p className="text-sm text-ink-soft">{mobility.allowed}</p>
        </div>
      </div>
    </section>
  );
}
