import { useState, useRef, useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Sparkles,
  X,
  Send,
  AlertTriangle,
  Settings2,
  Minus,
  Maximize2,
  Minimize2,
  RotateCcw,
  Paperclip,
  FileText,
} from "lucide-react";
import { mockPatient } from "../data/mockPatient";
import { askAIPartner, type AIFilePart } from "../lib/aiClient";
import { AI_KEYS } from "../config/aiKeys";
import { getDailyStatus } from "../lib/dailyStatus";

interface ChatMessage {
  role: "user" | "assistant" | "error" | "system";
  text: string;
  fileName?: string;
}

const SUGGESTIONS = [
  "Obat apa yang belum saya minum hari ini?",
  "Kenapa harus batasi cairan 1.500 ml?",
  "Kalau lupa jadwal obat pagi, bagaimana?",
  "Apa saja yang perlu disiapkan sebelum kontrol?",
];

const MAX_FILE_BYTES = 4 * 1024 * 1024; // 4MB — practical ceiling for a browser-side request

function buildLiveContext(): string {
  const s = getDailyStatus();
  const p = mockPatient;
  return `Konteks pasien:
- Diagnosis: ${p.diagnosisClinical} (${p.diagnosisLayman})
- Tindakan: ${p.procedure}
- Alergi: ${p.allergy}
- Daftar obat terjadwal: ${p.medications
    .filter((m) => m.block !== "PRN")
    .map((m) => `${m.name} ${m.dose} (${m.block})`)
    .join(", ")}
- Batas cairan harian: ${p.fluid.maxMl} ml
- Batas angkat beban: ${p.mobility.weightLimitKg} kg
- Kontrol berikutnya: ${p.followUp.location} bersama ${p.followUp.doctor}, dalam ${s.daysToFollowUp} hari

Progres hari ini (data aktual dari aplikasi, gunakan ini saat relevan):
- Obat terjadwal diminum: ${s.medsTaken} dari ${s.medsTotal}. Belum diminum: ${
    s.medsRemaining.length ? s.medsRemaining.join(", ") : "tidak ada, semua sudah diminum"
  }
- Obat pereda nyeri dada (PRN) dipakai: ${s.prnTakenToday} dari maksimal ${s.prnMax} kali
- Cairan yang sudah diminum: ${s.fluidMl} ml dari maksimal ${s.fluidMaxMl} ml
- Dokumen kontrol yang sudah disiapkan: ${s.checklistDone} dari ${s.checklistTotal}`;
}

function buildSystemPrompt(): string {
  return `Kamu adalah "Aegis Partner", pendamping edukasi profesional di dalam aplikasi AegisCare untuk pasien pasca rawat inap dan keluarganya.

${buildLiveContext()}

Gaya bicara: profesional namun hangat dan menarik — seperti tenaga kesehatan tepercaya yang komunikatif. Sapa secukupnya, jelaskan dengan terstruktur (gunakan poin bila membantu), tunjukkan empati secara natural tanpa berlebihan, dan hindari jawaban kaku atau template. Gunakan bahasa Indonesia yang sederhana dan mudah dipahami orang awam; jelaskan istilah medis bila terpaksa dipakai.

Kemampuan tambahan: jika pengguna melampirkan gambar atau dokumen (misalnya foto kemasan obat, hasil lab, atau lembar resep), analisis isinya secara relevan dengan konteks pemulihan pasien di atas dan jelaskan temuannya dengan bahasa yang mudah dipahami.

Batasan penting:
- Kamu BUKAN pengganti dokter. Jangan mendiagnosis atau mengubah dosis/instruksi obat yang sudah diresepkan, termasuk saat menganalisis file.
- Jika pertanyaan atau isi file menyangkut gejala gawat darurat (nyeri dada berat, sesak napas berat, pendarahan hebat, dsb), arahkan segera untuk menghubungi IGD/119, jangan hanya memberi saran umum.
- Jawaban ringkas namun lengkap — cukup untuk menjawab tuntas tanpa bertele-tele.
- Jangan menyebutkan nama teknologi, penyedia layanan, atau istilah teknis di balik dirimu — cukup bicara sebagai "Aegis Partner".`;
}

function buildLocalGreeting(): string {
  const s = getDailyStatus();
  const parts: string[] = [];
  parts.push(`Halo, saya Aegis Partner. Berikut ringkasan hari ini untuk ${mockPatient.name.replace("Tn. ", "")}:`);
  parts.push(`💊 Obat: ${s.medsTaken}/${s.medsTotal} dosis terjadwal sudah diminum.`);
  parts.push(`💧 Cairan: ${s.fluidMl}/${s.fluidMaxMl} ml.`);
  parts.push(`📋 Dokumen kontrol: ${s.checklistDone}/${s.checklistTotal} siap, ${s.daysToFollowUp} hari lagi.`);
  if (s.medsRemaining.length > 0) {
    parts.push(`Masih belum diminum: ${s.medsRemaining.join(", ")}.`);
  }
  parts.push("Ada yang ingin ditanyakan seputar rencana pemulihan? Kamu juga bisa melampirkan foto obat atau dokumen untuk saya bantu jelaskan.");
  return parts.join("\n");
}

function readFileAsPart(file: File): Promise<AIFilePart> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      const base64Data = result.split(",")[1] ?? "";
      resolve({ mimeType: file.type || "application/octet-stream", base64Data });
    };
    reader.onerror = () => reject(new Error("Gagal membaca file"));
    reader.readAsDataURL(file);
  });
}

export function AIPartnerButton() {
  const [open, setOpen] = useState(false);
  const [minimized, setMinimized] = useState(false);
  const [maximized, setMaximized] = useState(false);
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loading, setLoading] = useState(false);
  const [pendingFile, setPendingFile] = useState<{ name: string; part: AIFilePart } | null>(null);
  const [fileError, setFileError] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const keysConfigured = Boolean(AI_KEYS.geminiApiKey || AI_KEYS.groqApiKey);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, loading]);

  useEffect(() => {
    if (open && messages.length === 0) {
      setMessages([{ role: "system", text: buildLocalGreeting() }]);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  async function handleFilePick(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    setFileError(null);
    if (file.size > MAX_FILE_BYTES) {
      setFileError("Ukuran file terlalu besar (maks. 4MB).");
      return;
    }
    try {
      const part = await readFileAsPart(file);
      setPendingFile({ name: file.name, part });
    } catch {
      setFileError("File tidak bisa dibaca. Coba format lain.");
    }
  }

  async function handleSend(overrideText?: string) {
    const question = (overrideText ?? input).trim();
    const hasFile = !!pendingFile;
    if (!question && !hasFile) return;
    if (loading) return;

    const effectiveQuestion = question || "Tolong analisis file yang saya lampirkan ini.";
    setInput("");
    setMessages((prev) => [...prev, { role: "user", text: effectiveQuestion, fileName: pendingFile?.name }]);
    setLoading(true);
    const filePart = pendingFile?.part;
    setPendingFile(null);

    try {
      const result = await askAIPartner(buildSystemPrompt(), effectiveQuestion, filePart);
      setMessages((prev) => [...prev, { role: "assistant", text: result.text }]);
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          role: "error",
          text: filePart
            ? "Aegis Partner belum bisa menganalisis file ini saat ini. Coba lagi beberapa saat lagi."
            : "Aegis Partner belum bisa merespons saat ini. Coba lagi beberapa saat lagi.",
        },
      ]);
    } finally {
      setLoading(false);
    }
  }

  function handleNewChat() {
    setMessages([{ role: "system", text: buildLocalGreeting() }]);
    setPendingFile(null);
    setFileError(null);
  }

  function openPanel() {
    setOpen(true);
    setMinimized(false);
  }

  // ---- Minimized: a small docked bar, no backdrop, state stays intact ----
  if (open && minimized) {
    return (
      <motion.button
        onClick={() => setMinimized(false)}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        whileTap={{ scale: 0.96 }}
        className="fixed bottom-5 right-5 z-40 flex items-center gap-2 rounded-full bg-clinical-600 px-4 py-3 text-sm font-semibold text-white shadow-card"
      >
        <Sparkles className="h-4 w-4" />
        Aegis Partner
        {loading && <span className="h-2 w-2 animate-pulse rounded-full bg-white/80" />}
        <Maximize2 className="h-3.5 w-3.5 opacity-80" />
      </motion.button>
    );
  }

  return (
    <>
      {!open && (
        <motion.button
          onClick={openPanel}
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3, type: "spring", stiffness: 260, damping: 20 }}
          whileTap={{ scale: 0.92 }}
          whileHover={{ y: -2 }}
          className="fixed bottom-5 right-5 z-30 flex min-h-[52px] items-center gap-2 rounded-full bg-clinical-600 px-5 text-sm font-semibold text-white shadow-card transition-colors duration-150 hover:bg-clinical-700"
        >
          <Sparkles className="h-5 w-5" />
          Aegis Partner
        </motion.button>
      )}

      <AnimatePresence>
        {open && !minimized && (
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-labelledby="ai-partner-title"
            className="fixed inset-0 z-50 flex items-end justify-center bg-ink/50 p-0 backdrop-blur-sm sm:items-center sm:p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.18 }}
          >
            <motion.div
              initial={{ opacity: 0, y: 24, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 16, scale: 0.98 }}
              transition={{ type: "spring", stiffness: 340, damping: 30 }}
              className={`flex w-full flex-col overflow-hidden rounded-t-2xl bg-surface shadow-card transition-[max-width,height] duration-300 sm:rounded-2xl ${
                maximized
                  ? "h-[92vh] max-w-4xl sm:h-[88vh]"
                  : "h-[85vh] max-w-md sm:h-[70vh]"
              }`}
            >
              <div className="flex items-center justify-between border-b border-line px-5 py-3.5">
                <div className="flex items-center gap-2">
                  <Sparkles className="h-5 w-5 text-clinical-600" aria-hidden="true" />
                  <h2 id="ai-partner-title" className="font-display text-base font-semibold text-ink">
                    Aegis Partner
                  </h2>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={handleNewChat}
                    aria-label="Percakapan baru"
                    title="Percakapan baru"
                    className="rounded-full p-2 text-ink-faint transition hover:bg-canvas hover:text-ink active:scale-90"
                  >
                    <RotateCcw className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => setMinimized(true)}
                    aria-label="Kecilkan"
                    title="Kecilkan"
                    className="rounded-full p-2 text-ink-faint transition hover:bg-canvas hover:text-ink active:scale-90"
                  >
                    <Minus className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => setMaximized((v) => !v)}
                    aria-label={maximized ? "Perkecil" : "Perbesar"}
                    title={maximized ? "Perkecil" : "Perbesar"}
                    className="rounded-full p-2 text-ink-faint transition hover:bg-canvas hover:text-ink active:scale-90"
                  >
                    {maximized ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
                  </button>
                  <button
                    onClick={() => setOpen(false)}
                    aria-label="Tutup"
                    title="Tutup"
                    className="rounded-full p-2 text-ink-faint transition hover:bg-canvas hover:text-ink active:scale-90"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
              </div>

              <div ref={scrollRef} className="flex-1 space-y-3 overflow-y-auto px-5 py-4">
                {!keysConfigured && (
                  <div className="flex gap-2 rounded-xl bg-warn-50 p-3 text-sm text-warn-600">
                    <Settings2 className="h-4 w-4 shrink-0" />
                    <p>Aegis Partner belum diaktifkan admin situs. Ringkasan di bawah tetap berjalan seperti biasa.</p>
                  </div>
                )}

                {messages.map((m, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.2 }}
                    className={m.role === "user" ? "flex justify-end" : "flex justify-start"}
                  >
                    {m.role === "error" ? (
                      <div className="flex max-w-[85%] items-start gap-2 rounded-xl bg-danger-50 p-3 text-sm text-danger-600">
                        <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
                        <span>{m.text}</span>
                      </div>
                    ) : (
                      <div
                        className={
                          m.role === "user"
                            ? "max-w-[85%] rounded-2xl bg-clinical-600 px-4 py-2.5 text-sm text-white"
                            : "max-w-[85%] rounded-2xl bg-canvas px-4 py-2.5 text-sm text-ink"
                        }
                      >
                        {m.fileName && (
                          <div className="mb-1.5 flex items-center gap-1.5 rounded-lg bg-white/15 px-2 py-1 text-xs opacity-90">
                            <FileText className="h-3.5 w-3.5" />
                            {m.fileName}
                          </div>
                        )}
                        <p className="whitespace-pre-wrap">{m.text}</p>
                      </div>
                    )}
                  </motion.div>
                ))}

                {loading && (
                  <div className="flex justify-start">
                    <div className="flex items-center gap-1 rounded-2xl bg-canvas px-4 py-3">
                      {[0, 1, 2].map((i) => (
                        <motion.span
                          key={i}
                          className="h-1.5 w-1.5 rounded-full bg-ink-faint"
                          animate={{ opacity: [0.3, 1, 0.3] }}
                          transition={{ duration: 1, repeat: Infinity, delay: i * 0.15 }}
                        />
                      ))}
                    </div>
                  </div>
                )}

                {messages.length <= 1 && !loading && (
                  <div className="flex flex-wrap gap-2 pt-1">
                    {SUGGESTIONS.map((s) => (
                      <button
                        key={s}
                        onClick={() => handleSend(s)}
                        className="rounded-full border border-line bg-canvas px-3 py-1.5 text-xs text-ink-soft transition duration-150 hover:border-clinical-400 hover:text-clinical-700 active:scale-95"
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {(pendingFile || fileError) && (
                <div className="border-t border-line px-4 py-2">
                  {pendingFile && (
                    <div className="flex items-center gap-2 rounded-lg bg-clinical-50 px-3 py-1.5 text-xs text-clinical-700">
                      <FileText className="h-3.5 w-3.5 shrink-0" />
                      <span className="flex-1 truncate">{pendingFile.name}</span>
                      <button
                        onClick={() => setPendingFile(null)}
                        aria-label="Hapus lampiran"
                        className="rounded-full p-0.5 hover:bg-clinical-100"
                      >
                        <X className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  )}
                  {fileError && <p className="mt-1 text-xs text-danger-600">{fileError}</p>}
                </div>
              )}

              <div className="flex items-center gap-2 border-t border-line px-4 py-3">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*,.pdf"
                  className="hidden"
                  onChange={handleFilePick}
                />
                <button
                  onClick={() => fileInputRef.current?.click()}
                  aria-label="Lampirkan foto atau dokumen"
                  title="Lampirkan foto/dokumen untuk dianalisis"
                  className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-line text-ink-faint transition duration-150 hover:border-clinical-400 hover:text-clinical-700 active:scale-90"
                >
                  <Paperclip className="h-4.5 w-4.5" />
                </button>
                <input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSend()}
                  placeholder="Tulis pertanyaan…"
                  className="min-h-[44px] flex-1 rounded-xl border border-line bg-canvas px-3 text-sm text-ink outline-none transition focus:border-clinical-400"
                />
                <button
                  onClick={() => handleSend()}
                  disabled={loading || (!input.trim() && !pendingFile)}
                  aria-label="Kirim"
                  className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-clinical-600 text-white transition duration-150 hover:bg-clinical-700 active:scale-90 disabled:opacity-50"
                >
                  <Send className="h-4.5 w-4.5" />
                </button>
              </div>
              <p className="border-t border-line bg-canvas px-4 py-2 text-center text-xs text-ink-faint">
                Bukan pengganti dokter. File dikirim langsung untuk dianalisis, tidak disimpan di server.
              </p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
