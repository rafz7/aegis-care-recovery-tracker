import { HeartPulse, Stethoscope, AlertOctagon } from "lucide-react";
import { mockPatient } from "../data/mockPatient";

export function PatientHero() {
  return (
    <section className="rounded-2xl border border-line bg-surface p-5 shadow-card sm:p-6" aria-label="Profil pasien">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="font-display text-xl font-semibold text-ink sm:text-2xl">{mockPatient.name}</h1>
          <p className="mt-0.5 text-sm text-ink-soft">
            {mockPatient.age} Th &nbsp;·&nbsp; No. RM: {mockPatient.mrn}
          </p>
        </div>
        <div className="flex items-center gap-2 rounded-full bg-clinical-50 px-3 py-1.5 text-sm text-clinical-700">
          <Stethoscope className="h-4 w-4" aria-hidden="true" />
          DPJP: {mockPatient.dpjp}
        </div>
      </div>

      <div className="mt-5 grid gap-3 sm:grid-cols-2">
        <div className="flex items-start gap-3 rounded-xl bg-clinical-50 p-4">
          <HeartPulse className="mt-0.5 h-5 w-5 shrink-0 text-clinical-600" aria-hidden="true" />
          <div>
            <p className="text-sm font-medium text-clinical-600">Diagnosis utama</p>
            <p className="mt-0.5 font-display text-sm font-semibold text-ink">{mockPatient.diagnosisClinical}</p>
            <p className="text-sm text-ink-soft">({mockPatient.diagnosisLayman})</p>
          </div>
        </div>

        <div className="rounded-xl bg-clinical-50 p-4">
          <p className="text-sm font-medium text-clinical-600">Tindakan yang dilakukan</p>
          <p className="mt-0.5 text-sm font-medium text-ink">{mockPatient.procedure}</p>
        </div>
      </div>

      <div className="mt-3 flex items-start gap-3 rounded-xl border border-danger-100 bg-danger-50 p-4">
        <AlertOctagon className="mt-0.5 h-5 w-5 shrink-0 text-danger-500" aria-hidden="true" />
        <div>
          <p className="text-sm font-medium text-danger-600">Alergi obat</p>
          <p className="mt-0.5 text-sm font-semibold text-danger-600">{mockPatient.allergy}</p>
        </div>
      </div>
    </section>
  );
}
