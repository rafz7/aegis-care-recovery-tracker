import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, Info, X, Sunrise, Moon, Zap } from "lucide-react";
import { mockPatient, type Medication, type MedicationBlock } from "../data/mockPatient";
import { useLocalStorage } from "../lib/useLocalStorage";
import { cn, formatTimeID } from "../lib/utils";
import { Modal } from "./Modal";

interface DoseEntry {
  medicationId: string;
  dateKey: string; // YYYY-MM-DD, local
  timestamps: string[]; // ISO, supports multiple for PRN
}

function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

const blockMeta: Record<MedicationBlock, { label: string; icon: typeof Sunrise; time: string }> = {
  Pagi: { label: "Pagi", icon: Sunrise, time: "07.00 – 08.00" },
  Malam: { label: "Malam", icon: Moon, time: "20.00 – 21.00" },
  PRN: { label: "Bila Nyeri Dada", icon: Zap, time: "Sesuai kebutuhan" },
};

export function MedicationTracker() {
  const [log, setLog] = useLocalStorage<DoseEntry[]>("aegiscare.doseLog", []);
  const [infoMed, setInfoMed] = useState<Medication | null>(null);
  const key = todayKey();

  const entriesToday = useMemo(() => log.filter((e) => e.dateKey === key), [log, key]);

  const scheduledMeds = mockPatient.medications.filter((m) => m.block !== "PRN");
  const prnMed = mockPatient.medications.find((m) => m.block === "PRN")!;

  const takenCount = scheduledMeds.filter((m) => entriesToday.some((e) => e.medicationId === m.id)).length;
  const prnEntry = entriesToday.find((e) => e.medicationId === prnMed.id);
  const prnTakenCount = prnEntry?.timestamps.length ?? 0;
  const progressPct = scheduledMeds.length ? (takenCount / scheduledMeds.length) * 100 : 0;

  function toggleDose(med: Medication) {
    setLog((prev) => {
      const existing = prev.find((e) => e.dateKey === key && e.medicationId === med.id);
      if (med.block === "PRN") {
        if (existing && existing.timestamps.length >= (med.maxPerDay ?? 3)) return prev; // hard cap
        if (existing) {
          return prev.map((e) =>
            e === existing ? { ...e, timestamps: [...e.timestamps, new Date().toISOString()] } : e
          );
        }
        return [...prev, { medicationId: med.id, dateKey: key, timestamps: [new Date().toISOString()] }];
      }
      // scheduled dose: simple toggle on/off
      if (existing) {
        return prev.filter((e) => e !== existing);
      }
      return [...prev, { medicationId: med.id, dateKey: key, timestamps: [new Date().toISOString()] }];
    });
  }

  const grouped: MedicationBlock[] = ["Pagi", "Malam", "PRN"];

  return (
    <section className="rounded-2xl border border-line bg-surface p-5 shadow-card sm:p-6" aria-label="Jadwal obat">
      <div className="flex items-center justify-between gap-3">
        <h2 className="font-display text-lg font-semibold text-ink">Jadwal Minum Obat</h2>
        <span className="text-sm font-medium text-ink-soft">
          {takenCount} dari {scheduledMeds.length} dosis hari ini
        </span>
      </div>

      <div className="mt-3 h-2.5 w-full overflow-hidden rounded-full bg-canvas">
        <motion.div
          className="h-full rounded-full bg-safe-500"
          initial={false}
          animate={{ width: `${progressPct}%` }}
          transition={{ type: "spring", stiffness: 120, damping: 20 }}
        />
      </div>

      <div className="mt-5 space-y-5">
        {grouped.map((block) => {
          const meds = mockPatient.medications.filter((m) => m.block === block);
          if (meds.length === 0) return null;
          const Icon = blockMeta[block].icon;
          return (
            <div key={block}>
              <div className="mb-2 flex items-center gap-2 text-sm font-semibold text-ink-soft">
                <Icon className="h-4 w-4" aria-hidden="true" />
                {blockMeta[block].label}
                <span className="font-normal text-ink-faint">· {blockMeta[block].time}</span>
              </div>

              <ul className="space-y-2">
                {meds.map((med) => {
                  const entry = entriesToday.find((e) => e.medicationId === med.id);
                  const isPrn = med.block === "PRN";
                  const taken = isPrn ? (entry?.timestamps.length ?? 0) > 0 : !!entry;
                  const capped = isPrn && prnTakenCount >= (med.maxPerDay ?? 3);

                  return (
                    <li
                      key={med.id}
                      className={cn(
                        "flex items-center gap-3 rounded-xl border p-3 transition-colors duration-200",
                        taken && !isPrn ? "border-safe-100 bg-safe-50" : "border-line bg-canvas",
                        isPrn && "border-warn-100 bg-warn-50"
                      )}
                    >
                      <motion.button
                        onClick={() => toggleDose(med)}
                        disabled={capped}
                        whileTap={{ scale: 0.88 }}
                        aria-pressed={taken}
                        aria-label={`Tandai ${med.name} ${med.dose} sudah diminum`}
                        className={cn(
                          "flex h-11 w-11 shrink-0 items-center justify-center rounded-full border-2 transition-colors duration-200",
                          taken && !isPrn
                            ? "border-safe-500 bg-safe-500 text-white"
                            : isPrn
                            ? "border-warn-500 text-warn-500 hover:bg-warn-100"
                            : "border-line text-transparent hover:border-clinical-400",
                          capped && "cursor-not-allowed opacity-50"
                        )}
                      >
                        <AnimatePresence mode="wait" initial={false}>
                          {taken && !isPrn ? (
                            <motion.span
                              key="check"
                              initial={{ scale: 0, opacity: 0 }}
                              animate={{ scale: 1, opacity: 1 }}
                              exit={{ scale: 0, opacity: 0 }}
                              transition={{ type: "spring", stiffness: 500, damping: 20 }}
                            >
                              <Check className="h-5 w-5" />
                            </motion.span>
                          ) : (
                            <Check className="h-5 w-5" />
                          )}
                        </AnimatePresence>
                      </motion.button>

                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5">
                          <p className="truncate font-medium text-ink">
                            {med.name} <span className="text-ink-soft">{med.dose}</span>
                          </p>
                          <button
                            onClick={() => setInfoMed(med)}
                            aria-label={`Info tentang ${med.name}`}
                            className="rounded-full p-1 text-ink-faint transition hover:bg-white hover:text-clinical-600 active:scale-90"
                          >
                            <Info className="h-4 w-4" />
                          </button>
                        </div>
                        {isPrn ? (
                          <p className="text-xs font-medium text-warn-600">
                            {med.warning} &nbsp;({prnTakenCount}/{med.maxPerDay ?? 3} hari ini)
                          </p>
                        ) : entry ? (
                          <p className="text-xs text-safe-600">
                            Diminum pukul {formatTimeID(new Date(entry.timestamps[0]))}
                          </p>
                        ) : (
                          <p className="text-xs text-ink-faint">Belum diminum</p>
                        )}
                      </div>
                    </li>
                  );
                })}
              </ul>
            </div>
          );
        })}
      </div>

      <Modal open={!!infoMed} onClose={() => setInfoMed(null)} labelledBy="med-info-title" widthClass="max-w-sm">
        {infoMed && (
          <div className="p-5">
            <div className="flex items-start justify-between">
              <h3 id="med-info-title" className="font-display text-lg font-semibold text-ink">
                {infoMed.name} {infoMed.dose}
              </h3>
              <button
                onClick={() => setInfoMed(null)}
                aria-label="Tutup"
                className="rounded-full p-1.5 text-ink-faint hover:bg-canvas hover:text-ink active:scale-90"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <p className="mt-3 text-sm text-ink-soft">
              <span className="font-medium text-ink">Manfaat: </span>
              {infoMed.purpose}
            </p>
            {infoMed.caution && (
              <p className="mt-2 rounded-lg bg-clinical-50 p-3 text-sm text-clinical-700">{infoMed.caution}</p>
            )}
            {infoMed.warning && (
              <p className="mt-2 rounded-lg bg-warn-50 p-3 text-sm font-medium text-warn-600">{infoMed.warning}</p>
            )}
          </div>
        )}
      </Modal>
    </section>
  );
}
