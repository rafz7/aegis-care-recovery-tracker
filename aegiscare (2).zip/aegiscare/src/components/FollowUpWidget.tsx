import { useEffect, useState } from "react";
import { CalendarClock, MapPin, Check } from "lucide-react";
import { mockPatient } from "../data/mockPatient";
import { useLocalStorage } from "../lib/useLocalStorage";
import { formatDateID, formatTimeID } from "../lib/utils";

function useCountdown(targetISO: string) {
  const [now, setNow] = useState(() => new Date());

  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 60_000);
    return () => clearInterval(id);
  }, []);

  const target = new Date(targetISO);
  const diffMs = target.getTime() - now.getTime();
  const isPast = diffMs <= 0;
  const totalMinutes = Math.max(0, Math.floor(diffMs / 60000));
  const days = Math.floor(totalMinutes / (60 * 24));
  const hours = Math.floor((totalMinutes % (60 * 24)) / 60);

  return { days, hours, isPast, target };
}

export function FollowUpWidget() {
  const { followUp, checklist } = mockPatient;
  const { days, hours, isPast, target } = useCountdown(followUp.dateISO);
  const [checked, setChecked] = useLocalStorage<Record<string, boolean>>("aegiscare.checklist", {});

  function toggle(id: string) {
    setChecked((prev) => ({ ...prev, [id]: !prev[id] }));
  }

  const doneCount = checklist.filter((c) => checked[c.id]).length;

  return (
    <section className="rounded-2xl border border-line bg-surface p-5 shadow-card sm:p-6" aria-label="Jadwal kontrol">
      <h2 className="font-display text-lg font-semibold text-ink">Kontrol Poliklinik</h2>

      <div className="mt-3 flex items-center gap-4 rounded-xl bg-clinical-600 p-4 text-white">
        <CalendarClock className="h-8 w-8 shrink-0" aria-hidden="true" />
        <div>
          {isPast ? (
            <p className="font-display text-lg font-semibold">Sudah waktunya kontrol</p>
          ) : (
            <p className="font-display text-2xl font-semibold">
              {days} hari {hours} jam <span className="text-sm font-normal opacity-80">lagi</span>
            </p>
          )}
          <p className="text-sm opacity-90">
            {formatDateID(target)}, {formatTimeID(target)} WIB
          </p>
        </div>
      </div>

      <div className="mt-3 flex items-center gap-2 text-sm text-ink-soft">
        <MapPin className="h-4 w-4 text-clinical-600" aria-hidden="true" />
        {followUp.location} — {followUp.doctor}
      </div>

      <div className="mt-5">
        <div className="mb-2 flex items-center justify-between">
          <p className="text-sm font-semibold text-ink">Yang Perlu Dibawa</p>
          <span className="text-xs text-ink-faint">
            {doneCount}/{checklist.length} siap
          </span>
        </div>
        <ul className="space-y-2">
          {checklist.map((item) => {
            const isChecked = !!checked[item.id];
            return (
              <li key={item.id}>
                <button
                  onClick={() => toggle(item.id)}
                  aria-pressed={isChecked}
                  className="flex min-h-[44px] w-full items-center gap-3 rounded-xl border border-line bg-canvas px-3 py-2 text-left transition duration-150 hover:border-clinical-400 active:scale-[0.98]"
                >
                  <span
                    className={
                      isChecked
                        ? "flex h-6 w-6 shrink-0 items-center justify-center rounded-md bg-safe-500 text-white"
                        : "flex h-6 w-6 shrink-0 items-center justify-center rounded-md border-2 border-line"
                    }
                  >
                    {isChecked && <Check className="h-4 w-4" />}
                  </span>
                  <span className={isChecked ? "text-sm text-ink-faint line-through" : "text-sm text-ink"}>
                    {item.label}
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      </div>
    </section>
  );
}
