import { motion } from "framer-motion";
import { ShieldPlus } from "lucide-react";
import { EmergencyBanner } from "./components/EmergencyBanner";
import { PatientHero } from "./components/PatientHero";
import { MedicationTracker } from "./components/MedicationTracker";
import { CareProtocol } from "./components/CareProtocol";
import { HydrationDietTracker } from "./components/HydrationDietTracker";
import { FollowUpWidget } from "./components/FollowUpWidget";
import { DischargeImporter } from "./components/DischargeImporter";
import { AIPartnerButton } from "./components/AIPartnerButton";

function App() {
  function handleLoadDemo() {
    // Reset all locally-persisted tracking state back to a clean demo slate.
    ["aegiscare.doseLog", "aegiscare.fluid", "aegiscare.checklist"].forEach((k) =>
      window.localStorage.removeItem(k)
    );
    window.location.reload();
  }

  return (
    <div className="min-h-screen bg-canvas font-body">
      <EmergencyBanner />

      <motion.main
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: "easeOut" }}
        className="mx-auto max-w-3xl space-y-4 px-4 py-6 sm:px-6 sm:py-8"
      >
        <header className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <ShieldPlus className="h-6 w-6 text-clinical-600" aria-hidden="true" />
            <p className="font-display text-lg font-semibold text-ink">AegisCare</p>
          </div>
          <DischargeImporter onLoadDemo={handleLoadDemo} />
        </header>

        <PatientHero />
        <MedicationTracker />
        <CareProtocol />
        <HydrationDietTracker />
        <FollowUpWidget />

        <footer className="pt-4 text-center text-xs text-ink-faint">
          Selalu ikuti instruksi dokter yang merawat — aplikasi ini alat bantu pemantauan, bukan pengganti konsultasi
          medis.
        </footer>
      </motion.main>

      <AIPartnerButton />
    </div>
  );
}

export default App;
